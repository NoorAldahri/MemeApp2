//
//  MemeCollectionViewCell.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 08/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeImageView: UIImageView!

}
