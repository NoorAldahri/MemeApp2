//
//  image.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 10/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit


extension UIImage {
    
    // From Stack Overflow
    
    /// Resizes an image to the specified size.
    ///
    /// - Parameters:
    ///     - size: the size we desire to resize the image to.
    ///
    /// - Returns: the resized image.
    ///
    func imageWithSize(size: CGSize) -> UIImage? {
        
        UIGraphicsBeginImageContextWithOptions(size, false, UIScreen.main.scale)
        let rect = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
        draw(in: rect)
        
        let resultingImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return resultingImage
    }
}

