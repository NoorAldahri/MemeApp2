//
//  DetailViewController.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 09/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    var image: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = image
                
    }
}
