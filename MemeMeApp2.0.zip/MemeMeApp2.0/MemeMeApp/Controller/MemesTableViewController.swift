//
//  MemesTableViewController.swift
//  MemeMeApp
//
//  Created by Noor Aldahri on 08/08/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemesTableViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var tableView: UITableView!
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    
    @IBAction func addMeme(_ sender: Any) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! UINavigationController
        present(secondVC, animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MemeCell")!
        
        let meme = self.memes[(indexPath as NSIndexPath).row]
        
        // Set the image and the text
        
        cell.imageView?.image = meme.memedImage
        cell.imageView?.image = meme.memedImage?.imageWithSize(size: CGSize(width: 100, height: 100))
        cell.textLabel?.text = meme.topText + meme.bottomText
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        
        detailController.image = memes[indexPath.row].memedImage
        self.navigationController?.pushViewController(detailController, animated: true)

    }
    
}
